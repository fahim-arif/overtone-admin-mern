import React from 'react';
import {Link} from 'react-router-dom';
import {AppSetting} from '../../AppSetting'

function Header() {
  return <div style={{paddingTop:20}}>
     <button className="kt-header-menu-wrapper-close" id="kt_header_menu_mobile_close_btn"><i className="la la-close" /></button>
              <div className="kt-header-menu-wrapper" id="kt_header_menu_wrapper">
                <div id="kt_header_menu" className="kt-header-menu kt-header-menu-mobile  kt-header-menu--layout-default ">
                  <ul className="kt-menu__nav ">
                   
                    <li className="kt-menu__item  kt-menu__item--submenu kt-menu__item--rel" data-ktmenu-submenu-toggle="click" aria-haspopup="true"><Link to="javascript:;" className="kt-menu__link kt-menu__toggle"><span className="kt-menu__link-text">Links</span></Link>
                      <div className="kt-menu__submenu kt-menu__submenu--classic kt-menu__submenu--left">
                        <ul className="kt-menu__subnav">
                          <li className="kt-menu__item " aria-haspopup="true"><a href={AppSetting.url} target="_blank" className="kt-menu__link "><span className="kt-menu__link-icon"><svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" className="kt-svg-icon">
                                  <g stroke="none" strokeWidth={1} fill="none" fillRule="evenodd">
                                    <rect id="bound" x={0} y={0} width={24} height={24} />
                                    <path d="M8,17 C8.55228475,17 9,17.4477153 9,18 L9,21 C9,21.5522847 8.55228475,22 8,22 L3,22 C2.44771525,22 2,21.5522847 2,21 L2,18 C2,17.4477153 2.44771525,17 3,17 L3,16.5 C3,15.1192881 4.11928813,14 5.5,14 C6.88071187,14 8,15.1192881 8,16.5 L8,17 Z M5.5,15 C4.67157288,15 4,15.6715729 4,16.5 L4,17 L7,17 L7,16.5 C7,15.6715729 6.32842712,15 5.5,15 Z" id="Mask" fill="#000000" opacity="0.3" />
                                    <path d="M2,11.8650466 L2,6 C2,4.34314575 3.34314575,3 5,3 L19,3 C20.6568542,3 22,4.34314575 22,6 L22,15 C22,15.0032706 21.9999948,15.0065399 21.9999843,15.009808 L22.0249378,15 L22.0249378,19.5857864 C22.0249378,20.1380712 21.5772226,20.5857864 21.0249378,20.5857864 C20.7597213,20.5857864 20.5053674,20.4804296 20.317831,20.2928932 L18.0249378,18 L12.9835977,18 C12.7263047,14.0909841 9.47412135,11 5.5,11 C4.23590829,11 3.04485894,11.3127315 2,11.8650466 Z M6,7 C5.44771525,7 5,7.44771525 5,8 C5,8.55228475 5.44771525,9 6,9 L15,9 C15.5522847,9 16,8.55228475 16,8 C16,7.44771525 15.5522847,7 15,7 L6,7 Z" id="Combined-Shape" fill="#000000" />
                                  </g>
                                </svg></span><span className="kt-menu__link-text">Visit Website</span></a></li>                        
                        </ul>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
 

  </div>


  
}

export default Header;
