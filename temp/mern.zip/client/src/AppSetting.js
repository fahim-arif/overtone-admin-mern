export const AppSetting={
    name:"Overtone Acoustics",
    url:"http://overtoneacoustics.com/"
}