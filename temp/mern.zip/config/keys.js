module.exports = {
  // mongoURI: 'mongodb://localhost:27017/overtone',
  mongoURI:
    "mongodb+srv://mdm:mdm123456@cluster0-kwvxd.mongodb.net/mdm?retryWrites=true&w=majority",
  secretOrKey: "secret",
  useNewUrlParser: true,
};
